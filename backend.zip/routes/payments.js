const express = require("express");
const router = express.Router();
require("dotenv").config({ path: "../.env" }); // Ensure env vars are loaded relative to server.js
const { supabase, authenticateToken } = require("../server");

// --- Stripe Initialization ---
// Ensure Stripe keys are loaded from .env
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
const stripePublishableKey = process.env.STRIPE_PUBLISHABLE_KEY;

if (!stripeSecretKey || !stripePublishableKey) {
    console.error("Erro: Chaves Stripe (Secret e Publishable) não configuradas no .env");
}
// Initialize Stripe only if keys are present
const stripe = stripeSecretKey ? require("stripe")(stripeSecretKey) : null;

// --- Endpoint to Create Payment Intent --- 
// POST /api/payments/create-payment-intent
router.post("/create-payment-intent", authenticateToken, async (req, res) => {
    if (!stripe) {
        return res.status(500).json({ error: "Configuração do Stripe incompleta no servidor." });
    }
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }

    const { serviceId } = req.body; // Frontend needs to send the ID of the service being booked
    const clientId = req.user.id; // Get client ID from authenticated user

    if (!serviceId) {
        return res.status(400).json({ error: "ID do serviço é obrigatório." });
    }

    try {
        // 1. Get Service Details (Price and Provider ID)
        const { data: serviceData, error: serviceError } = await supabase
            .from("services")
            .select("price, provider_id, title")
            .eq("id", serviceId)
            .eq("is_active", true)
            .single();

        if (serviceError || !serviceData) {
            console.error("Erro ao buscar serviço ou serviço inativo:", serviceError);
            return res.status(404).json({ error: "Serviço não encontrado ou indisponível." });
        }

        const servicePrice = parseFloat(serviceData.price);
        const providerId = serviceData.provider_id;
        const serviceTitle = serviceData.title;

        if (isNaN(servicePrice) || servicePrice <= 0) {
            return res.status(400).json({ error: "Preço do serviço inválido." });
        }

        // 2. Create a Booking Record (initially pending payment)
        //    We need a booking ID to associate with the payment.
        const { data: bookingData, error: bookingError } = await supabase
            .from("bookings")
            .insert({
                client_id: clientId,
                service_id: serviceId,
                provider_id: providerId,
                status: "pending_payment", // Initial status
                total_price: servicePrice
            })
            .select("id") // Get the ID of the newly created booking
            .single();

        if (bookingError || !bookingData) {
            console.error("Erro ao criar registro de agendamento:", bookingError);
            return res.status(500).json({ error: "Não foi possível iniciar o agendamento." });
        }

        const bookingId = bookingData.id;

        // 3. Create Stripe Payment Intent
        // Amount should be in cents (or smallest currency unit)
        const amountInCents = Math.round(servicePrice * 100);

        const paymentIntent = await stripe.paymentIntents.create({
            amount: amountInCents,
            currency: "brl", // Set your currency
            metadata: { // Store relevant IDs for webhook processing
                booking_id: bookingId,
                client_id: clientId,
                service_id: serviceId,
                provider_id: providerId
            },
            // Enable future usage if needed, e.g., for saving cards (requires more setup)
            // setup_future_usage: 'off_session',
            description: `Pagamento para serviço: ${serviceTitle} (Booking ID: ${bookingId})`,
            // application_fee_amount: calculate commission later upon release
        });

        // 4. Create Payment Record (linking booking and payment intent)
        const { error: paymentInsertError } = await supabase
            .from("payments")
            .insert({
                booking_id: bookingId,
                gateway_transaction_id: paymentIntent.id, // Store Payment Intent ID
                amount: servicePrice,
                status: "pending", // Initial status
                payment_method: null // Will be updated by webhook
            });

        if (paymentInsertError) {
            console.error("Erro ao criar registro de pagamento:", paymentInsertError);
            // Consider rolling back the booking or handling this state
            return res.status(500).json({ error: "Erro ao registrar detalhes do pagamento." });
        }

        // 5. Update Booking with Payment ID
        const { error: bookingUpdateError } = await supabase
            .from("bookings")
            .update({ payment_id: paymentInsertError ? null : (await supabase.from('payments').select('id').eq('gateway_transaction_id', paymentIntent.id).single()).data.id })
            .eq("id", bookingId);
        
        if (bookingUpdateError) {
             console.error("Erro ao atualizar booking com payment_id:", bookingUpdateError);
             // Non-critical for payment flow itself, but log it.
        }

        // 6. Send the client secret back to the frontend
        res.send({
            clientSecret: paymentIntent.client_secret,
            bookingId: bookingId,
            publishableKey: stripePublishableKey // Send publishable key for frontend Stripe.js initialization
        });

    } catch (error) {
        console.error("Erro ao criar Payment Intent:", error);
        res.status(500).json({ error: "Erro interno ao processar pagamento." });
    }
});


// --- Endpoint for Stripe Webhooks ---
// POST /api/payments/webhook
// Use express.raw({type: 'application/json'}) middleware for this specific route BEFORE express.json()
// This is crucial for Stripe signature verification.
router.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
    if (!stripe) {
        return res.status(500).json({ error: "Configuração do Stripe incompleta no servidor." });
    }
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }

    const sig = req.headers["stripe-signature"];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!webhookSecret) {
        console.error("Erro: Stripe Webhook Secret não configurado no .env");
        return res.status(500).send("Webhook secret não configurado.");
    }

    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
        console.error(`Webhook signature verification failed: ${err.message}`);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    switch (event.type) {
        case "payment_intent.succeeded":
            const paymentIntentSucceeded = event.data.object;
            console.log("Webhook received: payment_intent.succeeded", paymentIntentSucceeded.id);
            await handlePaymentSuccess(paymentIntentSucceeded);
            break;
        // case 'payment_intent.processing':
        //     console.log('Webhook received: payment_intent.processing', event.data.object.id);
        //     // Update status if needed
        //     break;
        case "payment_intent.payment_failed":
            const paymentIntentFailed = event.data.object;
            console.log("Webhook received: payment_intent.payment_failed", paymentIntentFailed.id);
            await handlePaymentFailure(paymentIntentFailed);
            break;
        // ... handle other event types as needed (e.g., charge.refunded)
        default:
            console.log(`Unhandled event type ${event.type}`);
    }

    // Return a 200 response to acknowledge receipt of the event
    res.json({ received: true });
});

// --- Webhook Helper Functions ---
async function handlePaymentSuccess(paymentIntent) {
    const paymentIntentId = paymentIntent.id;
    const bookingId = paymentIntent.metadata.booking_id;
    const paymentMethod = paymentIntent.payment_method_types ? paymentIntent.payment_method_types[0] : 'unknown';

    if (!bookingId) {
        console.error(`Erro no webhook: Booking ID não encontrado nos metadados do PaymentIntent ${paymentIntentId}`);
        return; // Important to avoid processing without context
    }

    try {
        // Update Payment record
        const { error: paymentUpdateError } = await supabase
            .from("payments")
            .update({
                status: "held", // Payment successful, now held by platform
                paid_at: new Date(paymentIntent.created * 1000), // Use PaymentIntent creation time as paid time
                payment_method: paymentMethod
            })
            .eq("gateway_transaction_id", paymentIntentId);

        if (paymentUpdateError) {
            console.error(`Erro ao atualizar status do pagamento ${paymentIntentId} para 'held':`, paymentUpdateError);
            // Log error but continue to update booking if possible
        }

        // Update Booking record
        const { error: bookingUpdateError } = await supabase
            .from("bookings")
            .update({
                status: "confirmed" // Or 'pending_confirmation' if provider needs to accept
                // status: 'pending_confirmation'
            })
            .eq("id", bookingId)
            .eq("status", "pending_payment"); // Ensure we only update if it was pending

        if (bookingUpdateError) {
            console.error(`Erro ao atualizar status do booking ${bookingId} para 'confirmed':`, bookingUpdateError);
        } else {
            console.log(`Booking ${bookingId} status atualizado para 'confirmed' após pagamento.`);
            // TODO: Notify provider about the new confirmed booking
        }

    } catch (err) {
        console.error(`Erro inesperado ao processar sucesso do PaymentIntent ${paymentIntentId}:`, err);
    }
}

async function handlePaymentFailure(paymentIntent) {
    const paymentIntentId = paymentIntent.id;
    const bookingId = paymentIntent.metadata.booking_id;

    if (!bookingId) {
        console.error(`Erro no webhook: Booking ID não encontrado nos metadados do PaymentIntent ${paymentIntentId} (falha)`);
        return;
    }

    try {
        // Update Payment record
        const { error: paymentUpdateError } = await supabase
            .from("payments")
            .update({ status: "failed" })
            .eq("gateway_transaction_id", paymentIntentId);

        if (paymentUpdateError) {
            console.error(`Erro ao atualizar status do pagamento ${paymentIntentId} para 'failed':`, paymentUpdateError);
        }

        // Update Booking record (optional: could also delete or mark as failed)
        const { error: bookingUpdateError } = await supabase
            .from("bookings")
            .update({ status: "cancelled" }) // Mark booking as cancelled due to payment failure
            .eq("id", bookingId)
            .eq("status", "pending_payment");

        if (bookingUpdateError) {
            console.error(`Erro ao atualizar status do booking ${bookingId} para 'cancelled' após falha no pagamento:`, bookingUpdateError);
        } else {
            console.log(`Booking ${bookingId} status atualizado para 'cancelled' após falha no pagamento.`);
            // TODO: Notify client about the payment failure
        }

    } catch (err) {
        console.error(`Erro inesperado ao processar falha do PaymentIntent ${paymentIntentId}:`, err);
    }
}


// TODO: Add endpoint for client to confirm service completion
// This endpoint will trigger the payment release to the provider
// POST /api/bookings/:id/confirm-completion (Protected, Client only)

// TODO: Add logic/endpoint for releasing payment to provider
// This involves calculating commission and using Stripe Connect (or Transfers API)
// This might be triggered by the confirm-completion endpoint or a separate process.


module.exports = router;

