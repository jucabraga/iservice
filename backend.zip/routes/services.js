const express = require("express");
const router = express.Router();
const { supabase, authenticateToken, isProvider } = require("../server"); // Import Supabase, auth middleware, and provider check

// Middleware para verificar se o prestador é o dono do serviço
const isServiceOwner = async (req, res, next) => {
    const serviceId = req.params.id;
    const providerId = req.user.id; // ID do usuário autenticado (prestador)

    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }

    try {
        const { data, error } = await supabase
            .from("services")
            .select("provider_id")
            .eq("id", serviceId)
            .single();

        if (error || !data) {
            console.error("Erro ao buscar serviço ou serviço não encontrado:", error);
            return res.status(404).json({ error: "Serviço não encontrado." });
        }

        if (data.provider_id !== providerId) {
            return res.status(403).json({ error: "Acesso negado. Você não é o proprietário deste serviço." });
        }

        next(); // Usuário é o proprietário, pode prosseguir
    } catch (err) {
        console.error("Erro inesperado ao verificar proprietário do serviço:", err);
        res.status(500).json({ error: "Erro interno ao verificar propriedade do serviço." });
    }
};

// --- Rotas CRUD para Serviços ---

// POST /api/services - Criar um novo serviço (Apenas Prestadores)
router.post("/", authenticateToken, isProvider, async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const providerId = req.user.id; // ID do prestador logado
    const { category_id, title, description, price, duration_estimate } = req.body;

    if (!category_id || !title || !description || price === undefined) {
        return res.status(400).json({ error: "Campos obrigatórios: category_id, title, description, price." });
    }

    try {
        const { data, error } = await supabase
            .from("services")
            .insert({
                provider_id: providerId,
                category_id,
                title,
                description,
                price,
                duration_estimate,
                is_active: true // Serviço começa ativo por padrão
            })
            .select() // Retorna o registro inserido
            .single(); // Espera um único registro

        if (error) {
            console.error("Erro ao criar serviço:", error);
            return res.status(500).json({ error: "Erro interno ao criar serviço." });
        }

        res.status(201).json(data);
    } catch (err) {
        console.error("Erro inesperado ao criar serviço:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});

// GET /api/services - Listar todos os serviços ativos (Público)
// Adicionar filtros (categoria, busca, localização) pode ser feito aqui
router.get("/", async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    try {
        // Seleciona serviços ativos e informações básicas do prestador e categoria
        const { data, error } = await supabase
            .from("services")
            .select(`
                id,
                title,
                price,
                description,
                duration_estimate,
                categories ( name ),
                providers (
                    user_id,
                    is_verified,
                    average_rating,
                    users ( full_name )
                )
            `)
            .eq("is_active", true);

        if (error) {
            console.error("Erro ao listar serviços:", error);
            return res.status(500).json({ error: "Erro interno ao listar serviços." });
        }

        res.json(data);
    } catch (err) {
        console.error("Erro inesperado ao listar serviços:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});

// GET /api/services/:id - Obter detalhes de um serviço específico (Público)
router.get("/:id", async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const { id } = req.params;

    try {
        const { data, error } = await supabase
            .from("services")
            .select(`
                *,
                categories ( * ),
                providers (
                    *,
                    users ( * )
                )
            `)
            .eq("id", id)
            .eq("is_active", true)
            .single();

        if (error) {
            if (error.code === 'PGRST116') { // Código para "Row not found"
                 return res.status(404).json({ error: "Serviço não encontrado ou inativo." });
            }
            console.error("Erro ao buscar detalhes do serviço:", error);
            return res.status(500).json({ error: "Erro interno ao buscar detalhes do serviço." });
        }

        res.json(data);
    } catch (err) {
        console.error("Erro inesperado ao buscar serviço:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});

// PUT /api/services/:id - Atualizar um serviço (Apenas Prestador proprietário)
router.put("/:id", authenticateToken, isProvider, isServiceOwner, async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const { id } = req.params;
    const { category_id, title, description, price, duration_estimate, is_active } = req.body;

    // Constrói objeto apenas com campos fornecidos para atualização
    const updates = {};
    if (category_id !== undefined) updates.category_id = category_id;
    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (price !== undefined) updates.price = price;
    if (duration_estimate !== undefined) updates.duration_estimate = duration_estimate;
    if (is_active !== undefined) updates.is_active = is_active;

    if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "Nenhum campo fornecido para atualização." });
    }

    updates.updated_at = new Date(); // Atualiza timestamp

    try {
        const { data, error } = await supabase
            .from("services")
            .update(updates)
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error("Erro ao atualizar serviço:", error);
            return res.status(500).json({ error: "Erro interno ao atualizar serviço." });
        }

        res.json(data);
    } catch (err) {
        console.error("Erro inesperado ao atualizar serviço:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});

// DELETE /api/services/:id - Desativar um serviço (Apenas Prestador proprietário)
// Em vez de deletar, vamos marcar como inativo
router.delete("/:id", authenticateToken, isProvider, isServiceOwner, async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const { id } = req.params;

    try {
        const { data, error } = await supabase
            .from("services")
            .update({ is_active: false, updated_at: new Date() })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error("Erro ao desativar serviço:", error);
            return res.status(500).json({ error: "Erro interno ao desativar serviço." });
        }

        res.status(200).json({ message: "Serviço desativado com sucesso.", service: data });
        // Alternativamente, retornar status 204 No Content
        // res.sendStatus(204);

    } catch (err) {
        console.error("Erro inesperado ao desativar serviço:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});


module.exports = router;

