const express = require("express");
const router = express.Router();
require("dotenv").config({ path: "../.env" });
const { supabase, authenticateToken } = require("../server");

// Middleware to check if the authenticated user is the client of the booking
const isBookingClient = async (req, res, next) => {
    const bookingId = req.params.id;
    const clientId = req.user.id; // ID do usuário autenticado (cliente)

    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }

    try {
        const { data, error } = await supabase
            .from("bookings")
            .select("client_id")
            .eq("id", bookingId)
            .single();

        if (error || !data) {
            console.error("Erro ao buscar agendamento ou agendamento não encontrado:", error);
            return res.status(404).json({ error: "Agendamento não encontrado." });
        }

        if (data.client_id !== clientId) {
            return res.status(403).json({ error: "Acesso negado. Você não é o cliente deste agendamento." });
        }

        req.booking = data; // Attach booking data (or just ID) if needed later
        next(); // Usuário é o cliente, pode prosseguir
    } catch (err) {
        console.error("Erro inesperado ao verificar cliente do agendamento:", err);
        res.status(500).json({ error: "Erro interno ao verificar cliente do agendamento." });
    }
};

// --- Rotas de Agendamentos ---

// GET /api/bookings/my-bookings - Listar agendamentos do usuário logado (cliente ou prestador)
router.get("/my-bookings", authenticateToken, async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const userId = req.user.id;
    const userRole = req.user.user_metadata.role;

    try {
        let query = supabase.from("bookings").select(`
            *,
            services (*, categories(name)),
            clients:client_id ( users (full_name) ),
            providers:provider_id ( users (full_name) ),
            payments ( status, amount )
        `);

        if (userRole === 'client') {
            query = query.eq('client_id', userId);
        } else if (userRole === 'provider') {
            query = query.eq('provider_id', userId);
        } else {
            return res.status(403).json({ error: "Tipo de usuário inválido para esta consulta." });
        }

        const { data, error } = await query.order('created_at', { ascending: false });

        if (error) {
            console.error("Erro ao buscar agendamentos:", error);
            return res.status(500).json({ error: "Erro interno ao buscar agendamentos." });
        }

        res.json(data);

    } catch (err) {
        console.error("Erro inesperado ao buscar agendamentos:", err);
        res.status(500).json({ error: "Erro inesperado no servidor." });
    }
});


// POST /api/bookings/:id/confirm-completion - Cliente confirma a conclusão do serviço
router.post("/:id/confirm-completion", authenticateToken, isBookingClient, async (req, res) => {
    if (!supabase) {
        return res.status(500).json({ error: "Cliente Supabase não inicializado." });
    }
    const bookingId = req.params.id;
    const commissionPercentage = parseFloat(process.env.PLATFORM_COMMISSION_PERCENTAGE || 10);

    try {
        // 1. Fetch Booking and Payment details to ensure it's in the correct state
        const { data: bookingData, error: fetchError } = await supabase
            .from("bookings")
            .select(`
                status,
                total_price,
                payments ( id, status, amount, gateway_transaction_id )
            `)
            .eq("id", bookingId)
            .single();

        if (fetchError || !bookingData) {
            console.error("Erro ao buscar agendamento para confirmação:", fetchError);
            return res.status(404).json({ error: "Agendamento não encontrado." });
        }

        // Check current status - Should be 'confirmed' or 'pending_client_approval'
        // Allow confirmation if provider marked as done ('pending_client_approval') or if just 'confirmed'
        if (!["confirmed", "pending_client_approval"].includes(bookingData.status)) {
             return res.status(400).json({ error: `Não é possível confirmar a conclusão. Status atual: ${bookingData.status}` });
        }

        if (!bookingData.payments || bookingData.payments.status !== 'held') {
            return res.status(400).json({ error: "Pagamento não está retido ou não encontrado. Não é possível liberar." });
        }

        const paymentId = bookingData.payments.id;
        const totalAmount = parseFloat(bookingData.payments.amount);

        // 2. Calculate Commission and Provider Amount
        const platformFee = (totalAmount * commissionPercentage) / 100;
        const amountToProvider = totalAmount - platformFee;

        // 3. Update Booking Status to 'completed'
        const { error: bookingUpdateError } = await supabase
            .from("bookings")
            .update({ status: "completed", updated_at: new Date() })
            .eq("id", bookingId);

        if (bookingUpdateError) {
            console.error(`Erro ao atualizar status do booking ${bookingId} para 'completed':`, bookingUpdateError);
            // Don't proceed with payment release if booking update fails
            return res.status(500).json({ error: "Erro ao finalizar o agendamento." });
        }

        // 4. Update Payment Status to 'released'
        const { error: paymentUpdateError } = await supabase
            .from("payments")
            .update({
                status: "released",
                platform_fee: platformFee.toFixed(2),
                amount_released_to_provider: amountToProvider.toFixed(2),
                released_at: new Date()
            })
            .eq("id", paymentId);

        if (paymentUpdateError) {
            console.error(`Erro ao atualizar status do pagamento ${paymentId} para 'released':`, paymentUpdateError);
            // Log the error, but the booking is already marked completed.
            // Manual intervention might be needed for the payment record.
            // Consider adding a retry mechanism or flagging for admin review.
            return res.status(500).json({ error: "Agendamento finalizado, mas houve erro ao registrar a liberação do pagamento." });
        }

        // 5. *** Trigger Actual Payout to Provider (Stripe Connect / Transfers) ***
        // This part requires Stripe Connect setup where providers have connected accounts.
        // Example placeholder - DO NOT USE IN PRODUCTION WITHOUT FULL STRIPE CONNECT IMPLEMENTATION
        console.log(`Simulating Payout: Transferindo R$ ${amountToProvider.toFixed(2)} para o prestador associado ao booking ${bookingId}.`);
        // try {
        //     const transfer = await stripe.transfers.create({
        //         amount: Math.round(amountToProvider * 100), // Amount in cents
        //         currency: "brl",
        //         destination: "acct_PROVIDER_STRIPE_ACCOUNT_ID", // Get provider's Stripe Account ID
        //         transfer_group: `booking_${bookingId}`,
        //         metadata: { booking_id: bookingId, payment_id: paymentId }
        //     });
        //     console.log(`Stripe Transfer ${transfer.id} criado para booking ${bookingId}.`);
        //     // Optionally store transfer ID in payments table
        // } catch (stripeError) {
        //     console.error(`ERRO AO CRIAR TRANSFERÊNCIA STRIPE para booking ${bookingId}:`, stripeError);
        //     // Handle payout failure - flag for admin, potentially revert DB status?
        // }

        console.log(`Booking ${bookingId} concluído e pagamento ${paymentId} liberado (simulado).`);
        res.json({ message: "Serviço confirmado com sucesso! Pagamento liberado para o prestador." });

    } catch (err) {
        console.error(`Erro inesperado ao confirmar conclusão do booking ${bookingId}:`, err);
        res.status(500).json({ error: "Erro interno ao confirmar a conclusão do serviço." });
    }
});

// TODO: Add endpoint for provider to mark service as 'in_progress' or 'pending_client_approval'
// PUT /api/bookings/:id/update-status (Protected, Provider only)


module.exports = router;

